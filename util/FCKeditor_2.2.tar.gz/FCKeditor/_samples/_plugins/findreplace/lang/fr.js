﻿/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2005 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * "Support Open Source software. What about a donation today?"
 * 
 * File Name: fr.js
 * 	French language file for the sample plugin.
 * 
 * File Authors:
 * 		Benjamin Cartereau (b.cartereau@infass.com)
 */

FCKLang['DlgMyReplaceTitle']		= 'Plugin - Remplacer' ;
FCKLang['DlgMyReplaceFindLbl']		= 'Chercher:' ;
FCKLang['DlgMyReplaceReplaceLbl']	= 'Remplacer par:' ;
FCKLang['DlgMyReplaceCaseChk']		= 'Respecter la casse' ;
FCKLang['DlgMyReplaceReplaceBtn']	= 'Remplacer' ;
FCKLang['DlgMyReplaceReplAllBtn']	= 'Remplacer Tout' ;
FCKLang['DlgMyReplaceWordChk']		= 'Mot entier' ;

FCKLang['DlgMyFindTitle']			= 'Plugin - Chercher' ;
FCKLang['DlgMyFindFindBtn']			= 'Chercher' ;